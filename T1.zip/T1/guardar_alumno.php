<!DOCTYPE html>
<html>
<head>
	<title>Alumno</title>
	<link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>
	<h1>Ingresa el Alumno</h1>
<form action="alumno.php" method="post">
	<label >Nombre</label>
	<input type="text" name="nombre"><br>
	<label >Apellido Paterno</label>
	<input type="text" name="apaterno"><br>
	<label >Apellido Materno</label>
	<input type="text" name="amaterno"><br>
	<label >Direccion</label>
	<input type="text" name="direccion"><br>
	<label >Contacto</label>
	<input type="text" name="contacto"><br>
	<label >Correo</label>
	<input type="text" name="correo"><br>
	<input type="submit" name="Guardar">
</form>
</body>
</html>