<!DOCTYPE html>
<html>
<head>
    <title>Borrar Calificación</title>
</head>
<body>
<form action="borrar_calificacion.php" method="post">
    <div class="form">
        <h1>Borrar Calificación</h1>
        <div class="grupo">
            <input type="text" name="matricula" required><span class="barra"></span>
            <label>Matrícula</label>
        </div>
        <div class="grupo">
            <input type="text" name="materia" required><span class="barra"></span>
            <label>Nombre de la Materia</label>
        </div>
        <button type="submit">Borrar Calificación</button>
    </div>
</form>
</body>
</html>
