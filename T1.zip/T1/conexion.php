<?php 
class conexion{
private $host="localhost";
private $usuario="root";
private $password= "";
private $db="universidad";
private $conect;

public function __construct(){
	$connectString="mysql:host=".$this->host."; dbname=".$this->db."; charset-utf8";
	try{
		$this->conect=new PDO($connectString, $this->usuario, $this->password);
		$this->conect->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		echo "conexion exitosa";
	}
	catch(Exception $e){
		$this->conect="Error de conexión";
		echo "error".$e->getMessage();
	}
}

}
$connect=new conexion();
?>