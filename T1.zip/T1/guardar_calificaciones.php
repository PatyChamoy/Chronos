<!DOCTYPE html>
<html>
<head>
    <title>Ingresar Calificación</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>
<form action="calificaciones.php" method="post">
    <div class="form">
        <h1>Ingresar Calificación</h1>
        <div class="grupo">
            <input type="text" name="matricula" required><span class="barra"></span>
            <label>Matrícula</label>
        </div>
        <div class="grupo">
            <input type="text" name="materia" required><span class="barra"></span>
            <label>Nombre de la Materia</label>
        </div>
        <div class="grupo">
            <input type="text" name="calificacion" required><span class="barra"></span>
            <label>Calificación</label>
        </div>
        <button type="submit">Guardar</button>
    </div>
</form>
</body>
</html>
