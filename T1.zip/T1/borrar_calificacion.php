<?php
$host="localhost";
$user="root";
$password="";
$db="universidad";

try {
    if(isset($_POST['matricula']) && isset($_POST['materia'])) {
        $matricula = $_POST['matricula'];
        $materia = $_POST['materia'];

        $pdo = new PDO("mysql:host=$host;dbname=$db", $user, $password);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
        
        $stmt = $pdo->prepare("SELECT idmateria FROM materia WHERE materia = :materia");
        $stmt->bindParam(':materia', $materia);
        $stmt->execute();
        $result = $stmt->fetch();
        
        if($result) {
        
            $stmt_borrar = $pdo->prepare("DELETE FROM calificaciones WHERE matricula = :matricula AND idmateria = :idmateria");
            $stmt_borrar->bindParam(':matricula', $matricula);
            $stmt_borrar->bindParam(':idmateria', $result['idmateria']);
            $stmt_borrar->execute();
            
            echo "Calificación borrada correctamente.";
        } else {
            echo "Error: La materia '$materia' no existe.";
        }
    } else {
        echo "Error: Debes proporcionar la matrícula y el nombre de la materia.";
    }
} catch(PDOException $e) {
    echo "Error: " . $e->getMessage();
}
$pdo = null;
?>
