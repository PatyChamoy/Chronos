<?php
$host="127.0.0.1:3306";
$user="root";
$password="";
$db="universidad";
try{
	if(isset($_POST['nombre']) && isset($_POST['apaterno']) && isset($_POST['amaterno']) && isset($_POST['direccion']) && isset($_POST['contacto']) && isset($_POST['correo'])){
		$pdo=new PDO("mysql:host=$host;dbname=$db",$user,$password);
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$stmt=$pdo->prepare("INSERT INTO alumnos(nombre,apaterno,amaterno,direccion,contacto,correo) VALUES (:nombre,:apaterno,:amaterno,:direccion,:contacto,:correo)");
		$stmt->bindParam(':nombre',$_POST['nombre']);
		$stmt->bindParam(':apaterno',$_POST['apaterno']);
		$stmt->bindParam(':amaterno',$_POST['amaterno']);
		$stmt->bindParam(':direccion',$_POST['direccion']);
		$stmt->bindParam(':contacto',$_POST['contacto']);
		$stmt->bindParam(':correo',$_POST['correo']);
		$stmt->execute();
		echo "Alumno Ingresado";
      }
      else{
      	echo "error: debes ingresar datos";
      }
  }catch(PDOExeption $e){
  	echo "error".$e->getMessage();
  }

$pdo=null;
?>