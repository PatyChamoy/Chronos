<?php
$host="localhost";
$user="root";
$password="";
$db="universidad";

try {
    if(isset($_POST['matricula']) && isset($_POST['materia']) && isset($_POST['calificacion'])) {
        $matricula = $_POST['matricula'];
        $materia = $_POST['materia'];
        $calificacion = $_POST['calificacion'];

        $pdo = new PDO("mysql:host=$host;dbname=$db", $user, $password);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
        $stmt = $pdo->prepare("SELECT idmateria FROM materia WHERE materia = :materia");
        $stmt->bindParam(':materia', $materia);
        $stmt->execute();
        $result = $stmt->fetch();
        
        if($result) {
            // Verificar si ya existe una calificación para esta matrícula y materia
            $stmt_verificar = $pdo->prepare("SELECT * FROM calificaciones WHERE matricula = :matricula AND idmateria = :idmateria");
            $stmt_verificar->bindParam(':matricula', $matricula);
            $stmt_verificar->bindParam(':idmateria', $result['idmateria']);
            $stmt_verificar->execute();
            $existing_record = $stmt_verificar->fetch();

            if($existing_record) {
                // Si ya existe una calificación, actualizarla
                $stmt_modificar = $pdo->prepare("UPDATE calificaciones SET calificacion = :calificacion WHERE matricula = :matricula AND idmateria = :idmateria");
                $stmt_modificar->bindParam(':matricula', $matricula);
                $stmt_modificar->bindParam(':idmateria', $result['idmateria']);
                $stmt_modificar->bindParam(':calificacion', $calificacion);
                $stmt_modificar->execute();
                echo "Calificación modificada correctamente.";
            } else {
                // Si no existe una calificación, mostrar un mensaje de error
                echo "Error: No se encontró una calificación existente para la matrícula '$matricula' y la materia '$materia'.";
            }
        } else {
            echo "Error: La materia '$materia' no existe.";
        }
    } else {
        echo "Error: Debes proporcionar la matrícula, el nombre de la materia y la calificación.";
    }
} catch(PDOException $e) {
    echo "Error: " . $e->getMessage();
}
$pdo = null;
?>
