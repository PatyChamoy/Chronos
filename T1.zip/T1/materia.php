<?php
$host="localhost";
$user="root";
$password="";
$db="universidad";
try{
	if(isset($_POST['materia'])){
		$pdo=new PDO("mysql:host=$host;dbname=$db",$user,$password);
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$stmt=$pdo->prepare("INSERT INTO materia(materia) VALUES (:materia)");
		$stmt->bindParam(':materia',$_POST['materia']);
		$stmt->execute();
		echo "materia almacenada";
      }
      else{
      	echo "error: debes ingresar datos";
      }
  }catch(PDOExeption $e){
  	echo "error".$e->getMessage();
  }

$pdo=null;
?>