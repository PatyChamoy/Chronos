<!DOCTYPE html>
<html>
<head>
    <title>Actualizar Calificación</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>
<form action="actualizar_calificacion.php" method="post">
    <div class="form">
        <h1>Actualizar Calificación</h1>
        <div class="grupo">
            <input type="text" name="matricula" required><span class="barra"></span>
            <label>Matrícula</label>
        </div>
        <div class="grupo">
            <input type="text" name="materia" required><span class="barra"></span>
            <label>Nombre de la Materia</label>
        </div>
        <div class="grupo">
            <input type="text" name="calificacion" required><span class="barra"></span>
            <label>Nueva Calificación</label>
        </div>
        <button type="submit">Actualizar Calificación</button>
    </div>
</form>
</body>
</html>
