<?php
$host="localhost";
$user="root";
$password="";
$db="universidad";

try {
    if(isset($_POST['matricula']) && isset($_POST['materia']) && isset($_POST['calificacion'])) {
        $matricula = $_POST['matricula'];
        $materia = $_POST['materia'];
        $calificacion = $_POST['calificacion'];

        $pdo = new PDO("mysql:host=$host;dbname=$db", $user, $password);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
    
        $stmt = $pdo->prepare("SELECT idmateria FROM materia WHERE materia = :materia");
        $stmt->bindParam(':materia', $materia);
        $stmt->execute();
        $result = $stmt->fetch();
        
        if($result) {
            
            $stmt_actualizar = $pdo->prepare("UPDATE calificaciones SET calificacion = :calificacion WHERE matricula = :matricula AND idmateria = :idmateria");
            $stmt_actualizar->bindParam(':calificacion', $calificacion);
            $stmt_actualizar->bindParam(':matricula', $matricula);
            $stmt_actualizar->bindParam(':idmateria', $result['idmateria']);
            $stmt_actualizar->execute();
            
            echo "Calificación actualizada correctamente.";
        } else {
            echo "Error: La materia '$materia' no existe.";
        }
    } else {
        echo "Error: Debes proporcionar la matrícula, el nombre de la materia y la calificación.";
    }
} catch(PDOException $e) {
    echo "Error: " . $e->getMessage();
}
$pdo = null;
?>
