<!DOCTYPE html>
<html>
<head>
	<title>MATERIA</title>
	<link rel="stylesheet" type="text/css" href="styles.css">

</head>
<body>
	<h1>Ingresar Materia</h1>
<form action="materia.php" method="post">
	<label >Materia</label>
	<input type="text" name="materia"><br>
	<input type="submit" name="Guardar">
</form>
</body>
</html>