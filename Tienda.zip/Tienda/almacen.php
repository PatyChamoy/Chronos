<?php
require_once "conexion.php";

class Almacen {
    private $conexion;

    public function __construct($conexion) {
        $this->conexion = $conexion;
    }

    public function obtenerAlmacenes() {
        $sql = "SELECT * FROM Almacen";
        $resultado = $this->conexion->query($sql);
        if ($resultado->rowCount() > 0) {
            return $resultado->fetchAll(PDO::FETCH_ASSOC);
        } else {
            return [];
        }
    }
}

$almacen = new Almacen($conexion);


$almacenes = $almacen->obtenerAlmacenes();

?>